const questions = [
  {
    question: "What is Blockchain?",
    choices: [
      "A cryptocurrency",
      "A shared digital ledger",
      "A virtual currency",
      "A centralized database"
    ],
    answer: 1
  },
  {
    question: "What is Bitcoin?",
    choices: [
      "A cryptocurrency",
      "A technology company",
      "A paper currency",
      "An online bank"
    ],
    answer: 0
  },
  {
    question: "What's the term for adding transactions to a block in Blockchain?",
    choices: [
      "Mining",
      "Encryption",
      "Transaction",
      "Validation"
    ],
    answer: 0
  },
  {
    question: "What does 'hash' mean in Blockchain?",
    choices: [
      "A type of encryption algorithm",
      "An invalid transaction",
      "A virtual currency",
      "Mining software"
    ],
    answer: 0
  },
  {
    question: "Main characteristic of Blockchain that distinguishes it from other databases?",
    choices: [
      "It is centralized",
      "It is faster",
      "It is less secure",
      "It is decentralized"
    ],
    answer: 3
  },
  {
    question: "Who can see transactions on Blockchain?",
    choices: [
      "Only the people who make them",
      "Only the miners",
      "All Blockchain users",
      "None of the above"
    ],
    answer: 2
  },
  {
    question: "What is the main purpose of Bitcoin?",
    choices: [
      "To make international transactions cheaper and faster",
      "To offer an alternative form of investment",
      "To eliminate the need for banks",
      "All of the above"
    ],
    answer: 0
  },
  {
    question: "What is the maximum limit of Bitcoins that can be created?",
    choices: [
      "There is no limit",
      "1 million",
      "21 million",
      "50 million"
    ],
    answer: 2
  },
  {
    question: "How is the validity of a Bitcoin transaction verified?",
    choices: [
      "By a central bank",
      "By a government organization",
      "By the Bitcoin network miners",
      "None of the above"
    ],
    answer: 2
  },
  {
    question: "How are Bitcoins stored?",
    choices: [
      "In a bank account",
      "In a digital wallet",
      "In a paper wallet",
      "None of the above"
    ],
    answer: 1
  },
{
    question: "Why is Blockchain more secure than other databases?",
    choices: [
      "Because it is faster",
      "Because it is less transparent",
      "Because it is decentralized",
      "Because it is less costly"
    ],
    answer: 2
  },
  {
    question: "What does 'KYC' stand for in the world of cryptocurrencies?",
    choices: [
      "Know Your Currency",
      "Know Your Client",
      "Keep Your Currency",
      "Keep Your Client"
    ],
    answer: 1
  },
  {
    question: "What is the main objective of Blockchain technology in the financial system?",
    choices: [
      "To increase the speed of transactions",
      "To increase the security of transactions",
      "To reduce the cost of transactions",
      "All of the above"
    ],
    answer: 3
  },
  {
    question: "How can smart contracts be used in Blockchain?",
    choices: [
      "To automate processes in companies",
      "To verify the identity of users",
      "To create new cryptocurrencies",
      "None of the above"
    ],
    answer: 0
  },
  {
    question: "What is the difference between a cryptocurrency and a traditional currency?",
    choices: [
      "Cryptocurrencies can only be used online",
      "Cryptocurrencies are more secure than traditional currencies",
      "Cryptocurrencies are decentralized, while traditional currencies are centralized",
      "Cryptocurrencies have fewer regulations than traditional currencies"
    ],
    answer: 2
  },
  {
    question: "What is a 'fork' in Blockchain?",
    choices: [
      "A type of cryptocurrency",
      "A type of transaction",
      "An update to the Blockchain network that creates a new version of the blockchain",
      "An error in the blockchain"
    ],
    answer: 2
  },
  {
    question: "What does the acronym 'POW' mean in Bitcoin mining?",
    choices: [
      "Planning of Opportunities and Websites",
      "Proof of Work",
      "Power of the Network",
      "Program of Web Offers"
    ],
    answer: 1
  },
  {
    question: "How can Blockchain be used in the food industry?",
    choices: [
      "To track the supply chain of food",
      "To increase the taste of food",
      "To reduce the cost of food",
      "None of the above"
    ],
    answer: 0
  },
  {
    question: "Why are Bitcoin and other cryptocurrencies considered a threat to the traditional financial system?",
    choices: [
      "Because they allow for faster and cheaper transactions",
      "Because they are more secure than the traditional financial system",
      "Because they are not regulated by the government",
      "All of the above"
    ],
    answer: 2
  },
  {
    question: "How can Blockchain help to reduce the excess of rules in the current financial model?",
    choices: [
      "By decentralizing the management of financial data",
      "By increasing transparency and trust in the financial system",
      "By reducing the costs of financial transactions",
      "All of the above"
    ],
    answer: 3
  }
];

let currentQuestion = 0;
let score = 0;

const questionElem = document.getElementById("question");
const choicesElem = document.getElementById("choices");
const submitButton = document.getElementById("submit");
const scoreElem = document.getElementById("score");

// ...

function typeQuestionText() {
  const question = questions[currentQuestion];
  const text = question.question;
  let index = 0;

  // Ocultar #choices mientras se escribe la pregunta
  choicesElem.style.display = "none";

  function type() {
    if (index < text.length) {
      questionElem.textContent += text[index];
      index++;
      setTimeout(type, 50); // 50 ms entre cada letra
    } else {
      showChoices();
    }
  }

  type();
}

// ...


function showQuestion() {
  const question = questions[currentQuestion];
  questionElem.textContent = "";
  typeQuestionText();
}

// ...

function showChoices() {
  const question = questions[currentQuestion];
  choicesElem.innerHTML = "";

  function addButton(index) {
    if (index < question.choices.length) {
      const button = document.createElement("button");
      button.textContent = question.choices[index];
      button.addEventListener("click", () => {
        const buttons = choicesElem.getElementsByTagName("button");
        for (let j = 0; j < buttons.length; j++) {
          buttons[j].classList.remove("selected");
        }
        button.classList.add("selected");
      });
      choicesElem.appendChild(button);

      setTimeout(() => {
        addButton(index + 1);
      }, 800); // Tiempo entre la aparición de cada botón
    }
  }

  // Hacer visibles los botones después de que termine de escribirse la pregunta
  setTimeout(() => {
    // Mostrar #choices de nuevo
    choicesElem.style.display = "block";
    addButton(0);
  }, 0);

  submitButton.style.display = "inline";
}

// ...





function checkAnswer() {
  const question = questions[currentQuestion];
  const buttons = choicesElem.getElementsByTagName("button");
  for (let i = 0; i < buttons.length; i++) {
    if (i === question.answer) {
      buttons[i].classList.add("correct");
      if (buttons[i].classList.contains("selected")) {
        score++; // Increment the score if the correct answer is selected
      }
    } else if (buttons[i].classList.contains("selected")) {
      buttons[i].classList.add("incorrect");
    }
    buttons[i].disabled = true;
  }
  const answerElem = document.createElement("p");
  choicesElem.appendChild(answerElem);
  submitButton.style.display = "none";
  currentQuestion++;
  setTimeout(() => {
    if (currentQuestion < questions.length) {
      enableButtons();
      showQuestion();
    } else {
      showScore();
    }
  }, 3000); // wait 3 seconds before showing the next question
}


function enableButtons() {
  const buttons = choicesElem.getElementsByTagName("button");
  for (let i = 0; i < buttons.length; i++) {
    buttons[i].disabled = false;
    buttons[i].classList.remove("selected");
    buttons[i].classList.remove("correct");
    buttons[i].classList.remove("incorrect");
  }
}

function showScore() {
  questionElem.textContent = "";
  choicesElem.innerHTML = "";
  submitButton.style.display = "none";
  scoreElem.textContent = `You scored ${score} out of ${questions.length}!`;
}

submitButton.addEventListener("click", () => {
  if (choicesElem.getElementsByClassName("selected").length === 0) {
    alert("Please select an answer before submitting!");
    return;
  }
  checkAnswer();
});

showQuestion();
